package com.example.wishlist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val itemList = mutableListOf<Item>()
    private lateinit var itemAdapter: ItemAdapter
    private lateinit var editTextName: EditText
    private lateinit var editTextPrice: EditText
    private lateinit var editTextURL: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements and RecyclerView
        editTextName = findViewById(R.id.editTextName)
        editTextPrice = findViewById(R.id.editTextPrice)
        editTextURL = findViewById(R.id.editTextURL)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        itemAdapter = ItemAdapter(itemList)
        recyclerView.adapter = itemAdapter

        // Find the "Add to Wishlist" button and set its click listener
        val addButton: Button = findViewById(R.id.addButton)
        addButton.setOnClickListener {
            addItem() // Call the addItem function when the button is clicked
        }
    }

    private fun addItem() {
        val name = editTextName.text.toString()
        val price = editTextPrice.text.toString()
        val url = editTextURL.text.toString()

        if (name.isNotEmpty() && price.isNotEmpty() && url.isNotEmpty()) {
            val item = Item(name, price, url)
            itemList.add(item) // Add the item to the mutable list
            itemAdapter.notifyDataSetChanged() // Notify the adapter of the data change

            // Clear the input fields
            editTextName.text.clear()
            editTextPrice.text.clear()
            editTextURL.text.clear()
        }
    }
}
