package com.example.wishlist

data class Item(val name: String, val price: String, val url: String)


